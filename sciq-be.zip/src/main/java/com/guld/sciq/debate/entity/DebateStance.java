package com.guld.sciq.debate.entity;

public enum DebateStance {
    PRO,
    CON;

}