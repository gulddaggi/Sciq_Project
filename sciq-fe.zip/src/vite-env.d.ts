/// <reference types="vite/client" />
/// <reference types="vue-router" />
