package com.guld.sciq.search.dto;

public enum SearchSortType {
    RELEVANCE,
    NEWEST,
    OLDEST,
    MOST_POPULAR
} 