package com.guld.sciq.global.exception;

public class InvalidDebateStatusException extends RuntimeException {
    public InvalidDebateStatusException(String message) {
        super(message);
    }
} 