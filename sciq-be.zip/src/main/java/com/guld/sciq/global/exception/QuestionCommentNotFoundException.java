package com.guld.sciq.global.exception;

public class QuestionCommentNotFoundException extends RuntimeException {
    public QuestionCommentNotFoundException(String message) {
        super(message);
    }
} 