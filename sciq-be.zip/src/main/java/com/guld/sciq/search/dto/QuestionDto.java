package com.guld.sciq.search.dto;

public class QuestionDto {

}
