package com.guld.sciq.global.exception;

public class DebateCommentNotFoundException extends RuntimeException {
    public DebateCommentNotFoundException(String message) {
        super(message);
    }
} 