package com.guld.sciq.question.comment.dto;

import lombok.Getter;

public record QuestionCommentCreateDto(
    String content
) {
}