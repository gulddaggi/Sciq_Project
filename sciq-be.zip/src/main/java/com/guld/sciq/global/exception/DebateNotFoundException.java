package com.guld.sciq.global.exception;

public class DebateNotFoundException extends RuntimeException {
    public DebateNotFoundException(String message) {
        super(message);
    }
} 