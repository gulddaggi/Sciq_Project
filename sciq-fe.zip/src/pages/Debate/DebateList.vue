<template>
  <div class="debate-container">
    <h2>토론대회</h2>
    <p>토론대회 페이지는 현재 개발 중입니다.</p>
  </div>
</template>

<script setup lang="ts">
// 추후 구현 예정
</script>

<style scoped>
.debate-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

h2 {
  font-size: 24px;
  font-weight: 600;
  margin-bottom: 20px;
}
</style> 