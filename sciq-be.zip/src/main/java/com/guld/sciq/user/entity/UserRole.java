package com.guld.sciq.user.entity;

public enum UserRole {
    ROLE_STUDENT,
    ROLE_ADVISOR
}
