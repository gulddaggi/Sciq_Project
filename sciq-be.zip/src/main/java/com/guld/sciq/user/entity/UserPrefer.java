package com.guld.sciq.user.entity;

public enum UserPrefer {
	PHYSICS,
	CHEMISTRY,
	BIOLOGY,
	EARTH_SCIENCE,
	ASTRONOMY,
	DEFAULT
}
